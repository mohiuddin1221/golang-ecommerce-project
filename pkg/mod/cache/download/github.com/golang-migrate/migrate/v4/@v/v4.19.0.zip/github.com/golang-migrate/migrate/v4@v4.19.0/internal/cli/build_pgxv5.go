//go:build pgx5

package cli

import (
	_ "github.com/golang-migrate/migrate/v4/database/pgx/v5"
)
