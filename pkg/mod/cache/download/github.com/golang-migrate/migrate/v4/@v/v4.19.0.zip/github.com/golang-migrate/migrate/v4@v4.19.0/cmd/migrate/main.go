package main

import "github.com/golang-migrate/migrate/v4/internal/cli"

func main() {
	cli.Main(Version)
}
